# proiect-covid Pop Stefan & Racovita Cristina \n toate fisierele se afla in arhiva zip
